package com.example.springMvcExample.controller;

import java.sql.SQLException;

import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.model.IPOPlanned;

public interface IPOPlannedController {

	public boolean insertIPO(IPOPlanned ipoPlanned) throws SQLException;

	public ModelAndView getIPOPlannedList() throws SQLException, Exception;
}
