package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.model.Sector;

public interface SectorController {

	public boolean insertSector(Sector sector) throws SQLException;

	public ModelAndView getSectorList() throws Exception;

}
