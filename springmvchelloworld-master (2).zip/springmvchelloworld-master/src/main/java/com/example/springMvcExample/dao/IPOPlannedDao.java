package com.example.springMvcExample.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springMvcExample.model.IPOPlanned;

public interface IPOPlannedDao extends JpaRepository<IPOPlanned, Integer> {

	List<IPOPlanned> findBycompanyCode(int companyCode);

}
