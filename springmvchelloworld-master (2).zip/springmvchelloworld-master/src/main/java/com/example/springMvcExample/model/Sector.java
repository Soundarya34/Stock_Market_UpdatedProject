package com.example.springMvcExample.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "sectors")
public class Sector {

	@Id
	@Column(name = "sector_id")
	@NotNull(message = "please enter sector id")
	private Integer sectorId;

	@Column(name = "sector_name")
	@Pattern(regexp = "^[A-Za-z]+$", message = "Name must contain only alphabets") 
	@Size(min = 1, max = 30, message = "Name must be between 1 to 30 characters")
	@NotEmpty(message = "please enter sector name")
	private String sectorName;

	@Column(name = "brief")
	@Pattern(regexp = "^[A-Za-z]+$", message = "Brief must contain only alphabets") 
	@Size(min = 1, max = 30, message = "Brief must be between 1 to 30 characters")
	@NotEmpty(message = "please enter brief")
	private String brief;

	public Integer getSectorId() {
		return sectorId;
	}

	public void setSectorId(Integer sectorId) {
		this.sectorId = sectorId;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	@Override
	public String toString() {
		return "Sector [sectorId=" + sectorId + ", sectorName=" + sectorName + ", brief=" + brief + "]";
	}

}
