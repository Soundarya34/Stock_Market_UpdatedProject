package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import com.example.springMvcExample.model.IPOPlanned;


public interface IPOPlannedService {

public boolean insertIPO(IPOPlanned ipoPlanned ) throws SQLException;
	
	public List<IPOPlanned> getIPOPlannedList() throws SQLException;
	
	
}
