package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.IPOPlannedDao;

import com.example.springMvcExample.model.IPOPlanned;

@Service
public class IPOPlannedServiceImpl implements IPOPlannedService {

	@Autowired
	private IPOPlannedDao ipoPlannedDao;

	@Override
	public boolean insertIPO(IPOPlanned ipoPlanned) throws SQLException {
		// TODO Auto-generated method stub
		ipoPlannedDao.save(ipoPlanned);
		return true;
	}

	@Override
	public List<IPOPlanned> getIPOPlannedList() throws SQLException {
		// TODO Auto-generated method stub
		return ipoPlannedDao.findAll();
	}
}
