package com.example.springMvcExample.service;

import java.util.List;

import com.example.springMvcExample.model.StockPrice;

public interface StockPriceService {

	public List<StockPrice> getStockList();

	public void insertStock(StockPrice stockPrice);

}
